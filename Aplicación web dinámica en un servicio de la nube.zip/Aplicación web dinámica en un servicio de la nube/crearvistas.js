<script setup lang="ts">
import IForm from '@/components/form/IForm.vue'
</script>

<template>
  <section class="container">
    <IForm />
  </section>
</template>